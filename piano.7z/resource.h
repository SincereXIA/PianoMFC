//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by piano.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PIANO_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDB_unpress3                    129
#define IDB_unpress1                    130
#define IDB_unpress2                    131
#define IDB_press3                      132
#define IDB_press1                      133
#define IDB_press2                      134
#define IDB_HEAD                        135
#define IDB_unpress4                    136
#define IDB_unpress5                    137
#define IDB_unpress6                    138
#define IDB_unpress7                    139
#define IDB_press7                      141
#define IDB_press4                      142
#define IDB_press5                      143
#define IDB_press6                      144
#define IDC_KVAL                        1002
#define IDC_QKey                        1003
#define IDC_WKey                        1004
#define IDC_EKey                        1005
#define IDC_INIT_INFO                   1006
#define IDC_BUTTON1                     1007
#define IDC_BUTTON2                     1008
#define IDC_RKey                        1009
#define IDC_TKey                        1010
#define IDC_YKey                        1011
#define IDC_UKey                        1012
#define IDC_IKey                        1013
#define IDC_AKey                        1013
#define IDC_EKey3                       1014
#define IDC_SKey                        1014
#define IDC_UKey2                       1015
#define IDC_DKey                        1015
#define IDC_IKey2                       1016
#define IDC_FKey                        1016
#define IDC_EKey4                       1017
#define IDC_GKey                        1017
#define IDC_HKey                        1018
#define IDC_JKey                        1019
#define IDC_ZKey                        1020
#define IDC_XKey                        1021
#define IDC_CKey                        1022
#define IDC_VKey                        1023
#define IDC_BKey                        1024
#define IDC_NKey                        1025
#define IDC_MKey                        1026
#define IDC_BUTTON3                     1027
#define IDC_A2ZTrue                     1028
#define IDC_A2ZFalse                    1029
#define IDC_SoundLocalTrue              1030
#define IDC_SoundLocalFalse             1031

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
